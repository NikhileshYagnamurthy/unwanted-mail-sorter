document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("emails");
  try {
    const res = await fetch("http://127.0.0.1:5000/fetch-emails");
    const emails = await res.json();

    container.innerHTML = ""; // clear loading text

    emails.forEach(email => {
      const div = document.createElement("div");
      div.className = `email ${email.label.toLowerCase()}`;

      div.innerHTML = `
        <div class="subject">${email.subject}</div>
        <div class="label">${email.label}</div>
        <div class="confidence">Confidence: ${email.confidence.toFixed(2)}%</div>
      `;

      container.appendChild(div);
    });
  } catch (err) {
    container.innerHTML = "⚠️ Could not connect to backend.";
  }
});
